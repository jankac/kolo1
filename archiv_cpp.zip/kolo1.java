// Imie, Nazwisko, grupa(specjalnosc), nr. indeksu

class Kolo1 {
  public static void main(String[] args) {
    System.out.println("I love git!");
  }

}

