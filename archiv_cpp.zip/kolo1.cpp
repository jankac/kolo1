// Imie, Nazwisko, grupa(specjalnosc), nr. indeksu
//Janusz Kaczmarzyk, Zintegrowane Systemy zarz�dzania i analizy danych, 101366

#include <iostream>
using namespace std;

int main(int argc, char **argv) {

  cout<<"I don't like git"<<endl;

  return 0;
}

